package taskManager;

public class Task {
	private String name;
	private Domain domain;
	
	public Domain domain() {
		return domain;
	}

	public String name() {
		return name;
	}
}
