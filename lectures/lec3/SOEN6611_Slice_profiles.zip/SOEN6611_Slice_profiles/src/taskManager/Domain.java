package taskManager;

import java.util.Date;

public class Domain {
	private Date release;

	public Date releaseDate() {
		return release;
	}
}
