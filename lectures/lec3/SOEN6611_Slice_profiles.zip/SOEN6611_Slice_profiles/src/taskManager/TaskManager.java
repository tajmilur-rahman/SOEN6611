package taskManager;

public class TaskManager {

	public static Task[] getPeriodicPartsOf(Task t, Task[] expandedTasks) {
        int periods = 0;
        for (int i = 0; i < expandedTasks.length; i++) {
            if (expandedTasks[i].name().equals(t.name()))
                periods++;
        }
        Task[] instances = new Task[periods];
        int k = 0;
        for (int i = 0; i < expandedTasks.length; i++) {
            if (expandedTasks[i].name().equals(t.name())) {
                instances[k] = expandedTasks[i];
                k++;
            }
        }
        return sortTasks(instances);
    }
	
	public static Task[] sortTasks(Task[] tasks) {
        Task[] sorted = new Task[tasks.length];
        boolean[] ord = new boolean[tasks.length];
        for (int i = 0; i < ord.length; i++) {
            ord[i] = false;
        }
        int num = 0;
        while (num < tasks.length) {
            int min = Integer.MAX_VALUE;
            for (int i = 0; i < tasks.length; i++) {
                if ((!ord[i] && min == Integer.MAX_VALUE) ||
                    (!ord[i] &&
                     tasks[i].domain().releaseDate().compareTo(tasks[min].domain().
                        releaseDate()) < 0)) {
                    min = i;
                }
            }
            ord[min] = true;
            sorted[num] = tasks[min];
            num++;
        }
        return sorted;
    }
}
